<?php
return array(
    'controllers' => array(
        'value' => array(
            'namespaces' => array(
                '\\Awz\\BxOrm\\Api\\Controller' => 'api'
            )
        ),
        'readonly' => true
    )
);