<?
$arModuleVersion = array(
	"VERSION" => "1.0.7",
	"VERSION_DATE" => "2024-06-19 19:06:00"
);
?>