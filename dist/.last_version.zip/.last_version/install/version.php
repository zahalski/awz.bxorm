<?
$arModuleVersion = array(
	"VERSION" => "1.0.8",
	"VERSION_DATE" => "2024-08-26 08:41:00"
);
?>