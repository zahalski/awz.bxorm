drop table if exists b_awz_bxorm_hooks;
drop table if exists b_awz_bxorm_methods;