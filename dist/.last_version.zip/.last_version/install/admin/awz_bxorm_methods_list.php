<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/awz.bxorm/admin/methods_list.php");